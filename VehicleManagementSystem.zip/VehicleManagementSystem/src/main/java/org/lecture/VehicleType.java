package org.lecture;

public enum VehicleType {
    PKW,
    TRANSPORTER,
    MOTORRAD

}


